--
-- Create user
-- Since we are testing our project in cubist,
-- we are using this credential given by cubist administrator
--

CREATE USER 'dannych'@'localhost' IDENTIFIED BY 'U6dPvb2m';